import React from "react";
import ChatLayout from "./components/ChatLayout.jsx";

export default function App() {
  return (
    <div className="app-shell">
      <ChatLayout />
    </div>
  );
}
