import os
from dotenv import load_dotenv
from typing import Dict, Any

# Load environment variables
load_dotenv()

def get_azure_openai_config() -> Dict[str, Any]:
    """
    Get Azure OpenAI configuration for AutoGen agents
    Returns configuration dictionary for both agents using same credentials
    """
    return {
        "config_list": [
            {
                "model": os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o"),
                "api_key": os.getenv("AZURE_OPENAI_API_KEY"),
                "base_url": os.getenv("AZURE_OPENAI_ENDPOINT"),
                "api_type": "azure",
                "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
                "azure_deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
            }
        ],
        "temperature": 0.7,
        "timeout": 60,
    }

def validate_config():
    """Validate that all required environment variables are set"""
    required_vars = [
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT", 
        "AZURE_OPENAI_DEPLOYMENT_NAME"
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    print("✓ Azure OpenAI configuration validated successfully!")
    return True