# AutoGen A2A PoC with Azure OpenAI GPT-4o

This project demonstrates various Agent-to-Agent (A2A) use cases using Microsoft AutoGen framework with Azure OpenAI GPT-4o model.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Azure OpenAI account with GPT-4o deployment
- Azure OpenAI API key and endpoint

### Installation

1. **Clone/Download the project**
   ```powershell
   cd "c:\Users\Viraj.x.Raina\OneDrive - InterGlobe Aviation Limited\Documents\AutoGen"
   ```

2. **Create virtual environment**
   ```powershell
   python -m venv autogen_env
   .\autogen_env\Scripts\Activate.ps1
   ```

3. **Install dependencies**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Configure Azure OpenAI**
   - Copy `.env.example` to `.env`
   - Fill in your Azure OpenAI credentials:
   ```
   AZURE_OPENAI_API_KEY=your_api_key_here
   AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
   ```

5. **Run the demos**
   ```powershell
   python main.py
   ```

## 🎯 A2A Use Cases Demonstrated

### 1. **Code Review & Development**
- **Scenario**: Developer agent writes code, Reviewer agent provides feedback
- **Benefits**: Automated code quality assurance, knowledge sharing
- **Real-world**: Code review automation, mentoring junior developers

### 2. **Research & Analysis**
- **Scenario**: Researcher agent gathers data, Analyst agent provides insights
- **Benefits**: Comprehensive analysis, objective insights
- **Real-world**: Market research, competitive analysis, trend analysis

### 3. **Problem Solving**
- **Scenario**: Brainstormer agent generates ideas, Critic agent evaluates them
- **Benefits**: Balanced creativity and feasibility assessment
- **Real-world**: Innovation workshops, strategic planning, solution design

### 4. **Content Creation Pipeline**
- **Scenario**: Writer agent creates content, Editor agent refines it
- **Benefits**: Consistent quality, brand voice alignment
- **Real-world**: Marketing content, documentation, communications

## 🔧 Configuration Details

### Azure OpenAI Setup
Both agents use the same Azure OpenAI credentials as requested:
- **Model**: GPT-4o
- **API Type**: Azure
- **Shared Configuration**: Same endpoint, API key, and deployment for both agents

### Agent Configuration
```python
llm_config = {
    "config_list": [
        {
            "model": "gpt-4o",
            "api_key": "your_azure_openai_api_key",
            "base_url": "https://your-resource.openai.azure.com/", 
            "api_type": "azure",
            "api_version": "2024-02-01",
            "azure_deployment": "gpt-4o",
        }
    ],
    "temperature": 0.7,
    "timeout": 60,
}
```

## 📁 Project Structure

```
AutoGen/
├── main.py                           # Main demo runner
├── config.py                         # Azure OpenAI configuration
├── requirements.txt                  # Python dependencies
├── .env.example                      # Environment variables template
├── use_case_1_code_review.py        # Code review demonstration
├── use_case_2_research_analysis.py  # Research & analysis demo
├── use_case_3_problem_solving.py    # Problem solving demo
├── use_case_4_content_creation.py   # Content creation demo
└── README.md                         # This file
```

## 🌟 Additional A2A Use Cases (Future Extensions)

### 5. **Data Processing Chain**
- **Extractor Agent**: Pulls data from various sources
- **Transformer Agent**: Cleans, processes, and structures data
- **Use Case**: ETL pipelines, data preparation for analytics

### 6. **Customer Support Escalation**
- **First-line Agent**: Handles basic customer queries
- **Specialist Agent**: Takes over complex technical issues
- **Use Case**: Intelligent support ticket routing and escalation

### 7. **Financial Analysis**
- **Data Collector Agent**: Gathers market data and financial metrics
- **Investment Analyst Agent**: Provides investment recommendations
- **Use Case**: Automated investment research, portfolio analysis

### 8. **Quality Assurance Testing**
- **Test Generator Agent**: Creates comprehensive test cases
- **Validator Agent**: Executes tests and reports results
- **Use Case**: Automated testing workflows, QA processes

### 9. **Multi-language Translation & Localization**
- **Translator Agent**: Converts text between languages
- **Cultural Advisor Agent**: Adapts content for local markets
- **Use Case**: Global content localization, cultural adaptation

### 10. **Document Workflow**
- **Summarizer Agent**: Creates abstracts and key points
- **Fact-checker Agent**: Verifies information accuracy
- **Use Case**: Document processing, content verification

## 🛠️ Customization

### Adding New Use Cases
1. Create a new Python file following the pattern `use_case_X_name.py`
2. Import and use the shared `get_azure_openai_config()` function
3. Define agents with specific system messages for your use case
4. Add the new demo to `main.py`

### Modifying Agent Behavior
- Edit the `system_message` parameter in agent creation
- Adjust `temperature` in the config for more/less creative responses
- Modify `max_turns` to control conversation length

## 🔍 Troubleshooting

### Common Issues
1. **Missing API Key**: Ensure `.env` file has correct Azure OpenAI credentials
2. **Import Errors**: Install all dependencies with `pip install -r requirements.txt`
3. **Agent Timeout**: Increase `timeout` value in config if responses are slow
4. **PowerShell Execution Policy**: Run `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

### Debug Mode
Set `human_input_mode="ALWAYS"` in UserProxyAgent to interact directly with the conversation.

## 📊 Expected Outputs

Each demo shows:
- Agent-to-agent conversation logs
- Collaborative problem-solving in action
- Quality improvements through multi-agent review
- Different perspectives and expertise being applied

## 🎯 Business Value

This A2A approach provides:
- **Quality Assurance**: Multiple agents reviewing each other's work
- **Diverse Perspectives**: Different agent specializations
- **Scalability**: Automated workflows for complex tasks
- **Consistency**: Repeatable processes and quality standards
- **Efficiency**: Parallel processing and specialized expertise

## 🔜 Next Steps

1. **Run the demos** to see A2A collaboration in action
2. **Customize system messages** for your specific domain
3. **Add new use cases** relevant to your business needs
4. **Integrate with your existing systems** and workflows
5. **Scale up** with more specialized agents for complex workflows

---

**Note**: Make sure to keep your Azure OpenAI API keys secure and never commit them to version control.