"""
AutoGen A2A PoC: Code Review Use Case - SIMPLIFIED
Direct agent-to-agent communication without GroupChat complexity
"""
import autogen
from config import get_azure_openai_config, validate_config
from termcolor import colored

def setup_code_review_agents():
    """Setup Developer and Reviewer agents with same Azure OpenAI credentials"""
    
    validate_config()
    llm_config = get_azure_openai_config()
    
    # Developer Agent
    developer = autogen.AssistantAgent(
        name="Developer",
        system_message="""You are a Python developer. When given a task:
        1. Write clean, complete Python code
        2. Include proper documentation
        3. Listen to feedback and implement suggestions
        
        After writing code, always pass it to the CodeReviewer for review.""",
        llm_config=llm_config,
    )
    
    # Reviewer Agent  
    reviewer = autogen.AssistantAgent(
        name="CodeReviewer",
        system_message="""You are a code reviewer. When you receive code:
        1. Analyze it for correctness, efficiency, and best practices
        2. Provide specific, constructive feedback
        3. If good, say "APPROVED" 
        4. If needs changes, explain what and why
        
        Be thorough but supportive in your reviews.""",
        llm_config=llm_config,
    )
    
    return developer, reviewer

def run_code_review_demo():
    """Run simple A2A code review"""
    print(colored("\n🚀 Simple A2A Code Review", "cyan", attrs=["bold"]))
    
    developer, reviewer = setup_code_review_agents()
    
    task = """
    Create a Python function that processes user data:
    1. Filter active users (status == 'active')
    2. Calculate average age of active users  
    3. Return summary with count, avg age, and names
    
    Include error handling and documentation.
    """
    
    print(colored(f"\n📋 Task: {task}", "yellow"))
    print(colored("\n🤝 Starting A2A interaction...", "green"))
    
    try:
        # SIMPLE A2A: Developer receives task and automatically involves Reviewer
        chat_result = developer.initiate_chat(
            reviewer,
            message=f"I received this task: {task}\n\nLet me implement it and then please review my code.",
            max_turns=6  # Allow back-and-forth conversation
        )
        
        print(colored("\n✅ A2A Code Review Complete!", "green"))
        
    except Exception as e:
        print(colored(f"❌ Error: {e}", "red"))

if __name__ == "__main__":
    run_code_review_demo()