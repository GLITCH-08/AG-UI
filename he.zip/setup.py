"""
Setup script for AutoGen A2A PoC
Handles environment setup and dependency installation
"""
import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def setup_environment():
    """Set up the AutoGen A2A environment"""
    print("🚀 AutoGen A2A PoC Setup")
    print("=" * 40)
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("❌ Python 3.8+ is required")
        return False
    
    print(f"✅ Python {python_version.major}.{python_version.minor}.{python_version.micro} detected")
    
    # Create virtual environment
    venv_name = "autogen_env"
    if not Path(venv_name).exists():
        if not run_command(f"python -m venv {venv_name}", "Creating virtual environment"):
            return False
    else:
        print(f"✅ Virtual environment '{venv_name}' already exists")
    
    # Activation commands for different platforms
    if os.name == 'nt':  # Windows
        activate_cmd = f"{venv_name}\\Scripts\\activate"
        pip_cmd = f"{venv_name}\\Scripts\\pip"
    else:  # Unix/Linux/MacOS
        activate_cmd = f"source {venv_name}/bin/activate"
        pip_cmd = f"{venv_name}/bin/pip"
    
    # Install dependencies
    if not run_command(f"{pip_cmd} install --upgrade pip", "Upgrading pip"):
        return False
    
    if not run_command(f"{pip_cmd} install -r requirements.txt", "Installing dependencies"):
        return False
    
    # Create .env file if it doesn't exist
    if not Path(".env").exists():
        if Path(".env.example").exists():
            if os.name == 'nt':
                run_command("copy .env.example .env", "Creating .env file")
            else:
                run_command("cp .env.example .env", "Creating .env file")
            
            print("\n🔧 Configuration Required:")
            print("Please edit the .env file with your Azure OpenAI credentials:")
            print("- AZURE_OPENAI_API_KEY")
            print("- AZURE_OPENAI_ENDPOINT") 
            print("- AZURE_OPENAI_DEPLOYMENT_NAME")
        else:
            print("❌ .env.example file not found")
            return False
    else:
        print("✅ .env file already exists")
    
    print("\n🎉 Setup completed successfully!")
    print("\nNext steps:")
    print(f"1. Activate virtual environment:")
    if os.name == 'nt':
        print(f"   .\\{venv_name}\\Scripts\\Activate.ps1")
    else:
        print(f"   source {venv_name}/bin/activate")
    print("2. Edit .env file with your Azure OpenAI credentials")
    print("3. Run: python main.py")
    
    return True

if __name__ == "__main__":
    setup_environment()