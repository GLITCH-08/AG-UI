"""
Main Demo Runner for AutoGen A2A PoC
Runs all use case demonstrations with Azure OpenAI GPT-4o
"""
import sys
import os
from termcolor import colored

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def main():
    """Main function to run all A2A demonstrations"""
    print(colored("=" * 70, "cyan", attrs=["bold"]))
    print(colored("🚀 AutoGen A2A Proof of Concept with Azure OpenAI GPT-4o", "cyan", attrs=["bold"]))
    print(colored("=" * 70, "cyan", attrs=["bold"]))
    
    print(colored("\n📋 Available A2A Use Case Demonstrations:", "yellow", attrs=["bold"]))
    print("1. Code Review & Development")
    print("2. Research & Analysis")  
    print("3. Problem Solving")
    print("4. Content Creation Pipeline")
    print("5. Aviation Operations & Safety (Industry-Specific)")
    print("6. Run All Demos")
    print("0. Exit")
    
    while True:
        try:
            choice = input(colored("\nEnter your choice (0-6): ", "green"))
            
            if choice == "0":
                print(colored("\n👋 Goodbye!", "cyan"))
                break
                
            elif choice == "1":
                from use_case_1_code_review import run_code_review_demo
                run_code_review_demo()
                
            elif choice == "2":
                from use_case_2_research_analysis import run_research_analysis_demo
                run_research_analysis_demo()
                
            elif choice == "3":
                from use_case_3_problem_solving import run_problem_solving_demo
                run_problem_solving_demo()
                
            elif choice == "4":
                from use_case_4_content_creation import run_content_creation_demo
                run_content_creation_demo()
                
            elif choice == "5":
                from use_case_5_aviation_specific import run_aviation_demo
                run_aviation_demo()
                
            elif choice == "6":
                print(colored("\n🎬 Running All Demonstrations...", "magenta", attrs=["bold"]))
                
                from use_case_1_code_review import run_code_review_demo
                from use_case_2_research_analysis import run_research_analysis_demo
                from use_case_3_problem_solving import run_problem_solving_demo
                from use_case_4_content_creation import run_content_creation_demo
                from use_case_5_aviation_specific import run_aviation_demo
                
                run_code_review_demo()
                run_research_analysis_demo()
                run_problem_solving_demo()
                run_content_creation_demo()
                run_aviation_demo()
                
                print(colored("\n✅ All demonstrations completed!", "green", attrs=["bold"]))
                
            else:
                print(colored("❌ Invalid choice. Please enter 0-6.", "red"))
                
        except KeyboardInterrupt:
            print(colored("\n\n👋 Demo interrupted. Goodbye!", "cyan"))
            break
        except Exception as e:
            print(colored(f"❌ Error: {e}", "red"))
            print(colored("Please check your configuration and try again.", "yellow"))

if __name__ == "__main__":
    main()