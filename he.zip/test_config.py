"""
Simple test script to verify Azure OpenAI configuration
Run this before using the main demos
"""
from config import get_azure_openai_config, validate_config
import os
from dotenv import load_dotenv

def test_configuration():
    """Test Azure OpenAI configuration"""
    print("🧪 Testing Azure OpenAI Configuration")
    print("=" * 40)
    
    try:
        # Load environment variables
        load_dotenv()
        
        # Validate configuration
        validate_config()
        
        # Get configuration
        config = get_azure_openai_config()
        
        print("✅ Configuration loaded successfully!")
        print(f"Model: {config['config_list'][0]['model']}")
        print(f"Endpoint: {config['config_list'][0]['base_url']}")
        print(f"API Version: {config['config_list'][0]['api_version']}")
        print(f"Deployment: {config['config_list'][0]['azure_deployment']}")
        print(f"Temperature: {config['temperature']}")
        
        # Test if API key is set (without revealing it)
        api_key = config['config_list'][0]['api_key']
        if api_key and len(api_key) > 10:
            print(f"✅ API Key: Set (***{api_key[-4:]})")
        else:
            print("❌ API Key: Not set or invalid")
            return False
        
        print("\n🎉 Configuration test passed!")
        print("You can now run the main demos with: python main.py")
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        print("\nPlease check:")
        print("1. .env file exists and has correct values")
        print("2. All required environment variables are set")
        print("3. Azure OpenAI endpoint and API key are valid")
        return False

if __name__ == "__main__":
    test_configuration()