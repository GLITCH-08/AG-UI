import asyncio
import logging
import os
import sys
import threading
import time
from typing import Any, Optional

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
import os
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.agents import SequentialAgent

# Define remote sub-agents (update URLs as needed)
email_writer_agent = RemoteA2aAgent(
    name="email_writer_agent",
    agent_card=f'http://localhost:8001{AGENT_CARD_WELL_KNOWN_PATH}',
    description="Agent that writes professional emails based on user requirements."
)

email_reviewer_agent = RemoteA2aAgent(
    name="email_reviewer_agent",
    agent_card=f'http://localhost:8002{AGENT_CARD_WELL_KNOWN_PATH}',
    description="Agent that reviews and provides feedback on email drafts."
)

# Create the Host ADK Agent as a SequentialAgent using the two sub-agents
host_agent = SequentialAgent(
    name="host_agent",
    sub_agents=[email_writer_agent, email_reviewer_agent],
    description="Host agent that orchestrates email writing and reviewing using sub-agents."
)
AGENT_CARD_WELL_KNOWN_PATH = "/.well-known/agent-card.json"

