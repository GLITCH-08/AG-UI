import os
from google.adk.agents import Agent
from openai import AsyncAzureOpenAI
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent

# Initialize Azure OpenAI client
azure_client = AsyncAzureOpenAI(
    api_key="9ZAbR0wCTZM4NKd1CfXw54FGI9POeowvA7A4LzZn6WMhdtIQmsXnJQQJ99BFAC77bzfXJ3w3AAAAACOG498W",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://6e-openai-sandbox-aops.openai.azure.com/"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
)

async def azure_email_writer_tool(request: str) -> str:
    """Write professional emails using Azure OpenAI."""
    try:
        system_prompt = """You are a professional email writing specialist. Your job is to:
        1. Write clear, professional, and well-structured emails
        2. Use appropriate tone based on the context (formal, informal, business, etc.)
        3. Include proper email structure (subject, greeting, body, closing)
        4. Make the email concise but comprehensive
        5. Ensure proper grammar and professional language
        
        Always format your response as a complete email with:
        - Subject line
        - Greeting  
        - Body paragraphs
        - Professional closing
        - Signature placeholder"""
        
        response = await azure_client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Write an email for: {request}"}
            ],
            temperature=0.7,
            max_tokens=500
        )
        
        email_content = response.choices[0].message.content
        return f"📧 EMAIL WRITER AGENT RESPONSE:\n\n{email_content}\n\n✅ Email draft completed by Email Writer Agent"
        
    except Exception as e:
        return f"❌ Email Writer Agent Error: {str(e)}"

root_agent = Agent(
    name="email_writer_agent",
    model="gemini-1.5-flash",
    description="Specialized agent that writes professional emails based on user requirements using Azure OpenAI integration",
    instruction=(
        "You are an expert email writer agent. Your primary function is to create professional, "
        "well-structured emails based on user requests. You have access to Azure OpenAI for enhanced "
        "email generation capabilities. Always respond only to the client agent and provide complete "
        "email drafts with proper formatting, tone, and structure."
    ),
    tools=[azure_email_writer_tool],
)
AGENT_CARD_WELL_KNOWN_PATH = "/.well-known/agent-card.json"
