import asyncio
import logging
import os
import sys
import threading
import time

from typing import Any

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
from dotenv import load_dotenv
from google.adk.a2a.executor.a2a_agent_executor import (
    A2aAgentExecutor,
    A2aAgentExecutorConfig,
)
from google.adk.agents import Agent, SequentialAgent
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import google_search
import click
from email_writer_agent import root_agent as email_writer_agent
from agent_executor import EmailWriterAgentExecutor

# Load environment variables
load_dotenv(dotenv_path="../../.env")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MissingAPIKeyError(Exception):
    """Exception for missing API key."""


@click.command()
@click.option("--host", default="localhost")
@click.option("--port", default=8001)
def main(host, port):
    # Validate Azure OpenAI configuration
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        raise MissingAPIKeyError("AZURE_OPENAI_API_KEY environment variable is required")
    
    logger.info("🚀 Starting Email Writer Agent with A2A SDK...")

    # Email Writer Agent card (metadata)
    agent_card = AgentCard(
        name='Email Writer Agent',
        description=email_writer_agent.description,
        url=f'http://{host}:{port}',
        version="1.0.0",
        defaultInputModes=["text", "text/plain"],
        defaultOutputModes=["text", "text/plain"],
        capabilities=AgentCapabilities(streaming=True),
        skills=[
            AgentSkill(
                id="professional_email_writing",
                name="Professional Email Writing",
                description="Creates professional, well-structured emails for various business scenarios",
                tags=["email", "writing", "professional", "communication", "azure-openai"],
                examples=[
                    "Write a meeting request email for next Tuesday",
                    "Create an apology email for a delayed shipment",
                    "Draft a follow-up email after a job interview",
                    "Write a professional introduction email to new team members"
                ],
            )
        ],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=EmailWriterAgentExecutor(
            agent=email_writer_agent,
        ),
        task_store=InMemoryTaskStore(),
    )

    server = A2AStarletteApplication(
        agent_card=agent_card, http_handler=request_handler
    )

    logger.info(f"✅ Email Writer Agent ready on http://{host}:{port}")
    uvicorn.run(server.build(), host=host, port=port)


if __name__ == "__main__":
    main()